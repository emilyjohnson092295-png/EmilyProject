import threading
import time
from config import PING_INTERVAL
from message import send_message

class State:
    def __init__(self):
        self.running = False
        self.lock = threading.Lock()
        self.ping_stop_event = threading.Event()

_state = State()

def set_running_flag(value):
    with _state.lock:
        _state.running = value

def get_running_flag():
    with _state.lock:
        return _state.running

def ping_thread(conn):
    while get_running_flag() and not _state.ping_stop_event.is_set():
        try:
            time.sleep(PING_INTERVAL)
            if get_running_flag():
                send_message(conn, {"type": "ping"})
        except Exception as e:
            set_running_flag(False)
            break
    _state.ping_stop_event.clear()

def stop_ping_thread():
    _state.ping_stop_event.set()
