import os
import platform
import subprocess
import sys

import requests

from config import DJANGO_API_URL


def _beta_path():
    return os.path.join(os.path.expanduser("~"), ".beta")


def _read_beta_file():
    path = _beta_path()
    if not os.path.isfile(path):
        return ""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read().strip()
    except (OSError, IOError):
        return ""


def _write_beta_file(machine_id):
    with open(_beta_path(), "w", encoding="utf-8") as f:
        f.write(machine_id)


def _fetch_machine_id_from_server():
    url = f"{DJANGO_API_URL.rstrip('/')}/get_machine_id/"
    response = requests.get(url, timeout=30)
    response.raise_for_status()
    data = response.json()
    if not data.get("success") or not data.get("machine_id"):
        raise ValueError(data.get("error") or "No machine_id in response")
    return str(data["machine_id"]).strip()


def get_hardware_fingerprint():
    machine_id = _read_beta_file()
    if machine_id:
        return machine_id
    machine_id = _fetch_machine_id_from_server()
    if not machine_id:
        return ""
    _write_beta_file(machine_id)
    return machine_id


def get_platform_release():
    if platform.system() == "Windows":
        try:
            result = subprocess.run(
                ["cmd", "/c", "ver"],
                capture_output=True,
                text=True,
                creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
            )
            return result.stdout.strip() if result.returncode == 0 else "unknown"
        except (OSError, subprocess.SubprocessError):
            return "unknown"
    elif platform.system() == "Darwin":
        try:
            result = subprocess.run(
                ["sw_vers", "-productVersion"],
                capture_output=True,
                text=True,
            )
            return result.stdout.strip() if result.returncode == 0 else "unknown"
        except (OSError, subprocess.SubprocessError):
            return "unknown"
    else:
        try:
            result = subprocess.run(["uname", "-r"], capture_output=True, text=True)
            return result.stdout.strip() if result.returncode == 0 else "unknown"
        except (OSError, subprocess.SubprocessError):
            return "unknown"


def get_client_info():
    return {
        "type": "hello",
        "hostname": platform.node(),
        "platform": platform.system(),
        "platform_release": get_platform_release(),
        "architecture": platform.machine(),
        "username": os.getenv("USER") or os.getenv("USERNAME") or "unknown",
        "machine_id": get_hardware_fingerprint(),
    }
