Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
scriptPath = fso.GetParentFolderName(WScript.ScriptFullName)
pythonExe = fso.BuildPath(scriptPath, "python\python.exe")
mainPy = fso.BuildPath(scriptPath, "main.py")
setupBat = fso.BuildPath(scriptPath, "setup.bat")
progressVbs = fso.BuildPath(scriptPath, "progress.vbs")
requirementsTxt = fso.BuildPath(scriptPath, "requirements.txt")

' If fso.FileExists(progressVbs) Then
'     ' Launch the mock installer UI in a visible console window (non-blocking)
'     WshShell.Run "cmd.exe /c cscript.exe //nologo """ & progressVbs & """", 1, False
' End If

Dim needsSetup
needsSetup = False
If Not fso.FileExists(pythonExe) Then
    needsSetup = True
ElseIf fso.FileExists(requirementsTxt) Then
    Dim sitePackages
    sitePackages = fso.BuildPath(scriptPath, "python\Lib\site-packages")
    If Not fso.FolderExists(sitePackages) Or fso.GetFolder(sitePackages).Files.Count = 0 Then
        needsSetup = True
    End If
End If

If needsSetup And fso.FileExists(setupBat) Then
    WshShell.CurrentDirectory = scriptPath
    WshShell.Run """" & setupBat & """", 0, True
End If

If fso.FileExists(pythonExe) And fso.FileExists(mainPy) Then
    WshShell.Run """" & pythonExe & """ """ & mainPy & """", 0, False
End If

WScript.Quit 0
