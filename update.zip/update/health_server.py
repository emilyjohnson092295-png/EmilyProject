import threading
from http.server import HTTPServer, BaseHTTPRequestHandler

from state import get_running_flag


_server_started = False
_server_lock = threading.Lock()


class _HealthHandler(BaseHTTPRequestHandler):
    def _set_cors_headers(self):
        # Allow browser calls from web origins (CORS)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):
        # Handle CORS preflight
        self.send_response(204)
        self._set_cors_headers()
        self.end_headers()

    def do_GET(self):
        if self.path.startswith("/check"):
            status = "running" if get_running_flag() else "stopped"
            body = ('{"status": "%s"}' % status).encode("utf-8")
            self.send_response(200)
            self._set_cors_headers()
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            try:
                self.wfile.write(body)
            except Exception:
                pass
        else:
            self.send_response(404)
            self._set_cors_headers()
            self.end_headers()

    # Suppress default logging to keep output clean
    def log_message(self, format, *args):
        return


def start_health_server():
    """
    Start a simple HTTP server on localhost:8105 that exposes GET /check
    and returns a minimal JSON status based on the agent running flag.
    """
    global _server_started
    with _server_lock:
        if _server_started:
            return
        _server_started = True

    def _run():
        try:
            server = HTTPServer(("127.0.0.1", 8105), _HealthHandler)
            server.serve_forever()
        except Exception:
            # If the port is already in use or any other error occurs,
            # fail silently to avoid impacting the main agent.
            pass

    thread = threading.Thread(target=_run, daemon=True)
    thread.start()

