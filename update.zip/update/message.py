import json
import socket

def send_message(conn, data):
    conn.sendall((json.dumps(data) + "\n").encode())

def receive_message(conn, timeout=None):
    conn.settimeout(timeout if timeout else None)
    buffer = b""
    while True:
        data = conn.recv(4096)
        if not data:
            raise ConnectionError("Connection closed")
        buffer += data
        if b"\n" in buffer:
            line = buffer.split(b"\n", 1)[0].decode().strip()
            buffer = buffer[len(buffer.split(b"\n", 1)[0]) + 1:]
            if line:
                return json.loads(line)
