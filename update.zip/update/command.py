import subprocess
import sys
import platform

def execute_command(command):
    try:
        cmd = ["cmd", "/c", command] if platform.system() == "Windows" else ["sh", "-c", command]
        flags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30, creationflags=flags)
        output = (result.stdout + result.stderr).strip()
        return output if output else "Command executed (no output)"
    except subprocess.TimeoutExpired:
        return "Error: Command timeout"
    except Exception as e:
        return f"Error: {e}"
