@echo off
set PYTHON_EMBEDDED_URL=https://www.python.org/ftp/python/3.14.0/python-3.14.0-embed-amd64.zip
set PYTHON_DIR=python
set PYTHON_EXE=%PYTHON_DIR%\python.exe
set GET_PIP_URL=https://bootstrap.pypa.io/get-pip.py

if not exist "%PYTHON_EXE%" (
    if not exist "%PYTHON_DIR%" mkdir "%PYTHON_DIR%"
    powershell -Command "Invoke-WebRequest -Uri '%PYTHON_EMBEDDED_URL%' -OutFile 'python-embedded.zip'"
    powershell -Command "Expand-Archive -Path 'python-embedded.zip' -DestinationPath '%PYTHON_DIR%' -Force"
    del python-embedded.zip
    (echo python314.zip& echo .& echo Lib\site-packages) > "%PYTHON_DIR%\python314._pth"
)

if not exist "%PYTHON_EXE%" exit /b 1

REM Install pip if not available
if not exist "get-pip.py" (
    powershell -Command "Invoke-WebRequest -Uri '%GET_PIP_URL%' -OutFile 'get-pip.py'"
)
if exist "get-pip.py" (
    "%PYTHON_EXE%" get-pip.py >nul 2>&1
)