Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
scriptPath = fso.GetParentFolderName(WScript.ScriptFullName)
pythonExe = fso.BuildPath(scriptPath, "python\python.exe")
launcherPy = fso.BuildPath(scriptPath, "launcher.py")

If fso.FileExists(pythonExe) And fso.FileExists(launcherPy) Then
    WshShell.Run """" & pythonExe & """ """ & launcherPy & """", 0, False
End If
