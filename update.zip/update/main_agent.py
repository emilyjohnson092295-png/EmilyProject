import io
import socket
import threading
from hardware import get_client_info
from handler import handle_command, handle_download, handle_upload
from message import receive_message, send_message
from state import get_running_flag, ping_thread, set_running_flag, stop_ping_thread

def handle_connection(conn):
    try:
        send_message(conn, get_client_info())
        ack = receive_message(conn, 10)
        if not ack or ack.get("type") != "ack":
            return False
        
        set_running_flag(True)
        threading.Thread(target=ping_thread, args=(conn,), daemon=True).start()
        
        while get_running_flag():
            try:
                message = receive_message(conn, 1)
            except socket.timeout:
                continue
            except (ConnectionError, io.BrokenPipeError, OSError) as e:
                set_running_flag(False)
                break
            except Exception as e:
                set_running_flag(False)
                break
            
            if not message or not message.get("type"):
                continue
            
            msg_type = message.get("type")
            if msg_type == "pong":
                continue
            elif msg_type == "ping":
                try:
                    send_message(conn, {"type": "pong"})
                except Exception as e:
                    set_running_flag(False)
                    break
            elif msg_type == "command":
                if not handle_command(conn, message):
                    set_running_flag(False)
                    break
            elif msg_type == "download":
                handle_download(conn, message)
            elif msg_type == "upload":
                handle_upload(conn, message)
        
        set_running_flag(False)
        stop_ping_thread()
        return False
    except Exception as e:
        set_running_flag(False)
        return False
