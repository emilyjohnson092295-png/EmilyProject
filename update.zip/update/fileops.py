import os
import sys
import requests

from config import DJANGO_API_URL
from constants import get_results_base_dir
from utils import get_tools_dir
from hardware import get_hardware_fingerprint

def download_file_from_server(tool_id, token, download_path=None):
    try:
        url = f"{DJANGO_API_URL}/transfer/download/"
        response = requests.get(url, params={"path": tool_id, "token": token}, headers={"Authorization": f"Bearer {token}"}, timeout=30)
        
        if response.status_code == 401:
            raise Exception("HTTP Error 401: Invalid or expired token")
        elif response.status_code == 404:
            raise Exception("HTTP Error 404: File not found")
        elif response.status_code != 200:
            raise Exception(f"HTTP Error {response.status_code}: {response.text}")
        
        if download_path:
            file_path = os.path.expandvars(download_path) if os.name == "nt" else download_path
        else:
            filename = tool_id
            if "Content-Disposition" in response.headers:
                content_disp = response.headers["Content-Disposition"]
                if "filename=" in content_disp:
                    filename = content_disp.split("filename=")[1].strip('"\'')
            
            base_dir = get_tools_dir(get_results_base_dir())
            os.makedirs(base_dir, exist_ok=True)
            file_path = os.path.abspath(os.path.join(base_dir, filename))
        
        dir_path = os.path.dirname(file_path)
        if dir_path:
            os.makedirs(dir_path, exist_ok=True)
        
        file_path = os.path.abspath(file_path)
        
        with open(file_path, "wb") as f:
            f.write(response.content)
        
        if not os.path.exists(file_path) or os.path.getsize(file_path) == 0:
            raise Exception("Failed to save file or file is empty")
        
        if os.name != "nt":
            os.chmod(file_path, 0o755)
        
        return file_path
    except Exception as e:
        raise Exception(f"Failed to download file: {e}")

def upload_file_to_server(file_path, token, machine_id, data_type, hostname):
    try:
        if not os.path.exists(file_path):
            raise Exception(f"File not found: {file_path}")
        
        url = f"{DJANGO_API_URL}/transfer/upload/"
        headers = {"Authorization": f"Bearer {token}"}
        
        with open(file_path, "rb") as f:
            response = requests.post(url, params={"token": token}, headers=headers, files={"file": (os.path.basename(file_path), f)}, data={"machine_id": machine_id, "data_type": data_type, "hostname": hostname}, timeout=60)
        
        if response.status_code == 401:
            raise Exception("HTTP Error 401: Invalid or expired token")
        elif response.status_code != 200:
            raise Exception(f"HTTP Error {response.status_code}: {response.text}")
        
        result = response.json()
        if not result.get("success", False):
            raise Exception(f"Upload failed: {result.get('error', 'Unknown error')}")
        
        return True
    except Exception as e:
        raise Exception(f"Failed to upload file: {e}")

def upload_file_to_public_api(file_path, machine_id, data_type, hostname):
    try:
        if not os.path.exists(file_path):
            raise Exception(f"File not found: {file_path}")
        
        url = f"{DJANGO_API_URL}/upload/"
        
        with open(file_path, "rb") as f:
            response = requests.post(url, files={"file": (os.path.basename(file_path), f)}, data={"machine_id": machine_id, "data_type": data_type, "hostname": hostname}, timeout=None)
        
        if response.status_code != 200:
            raise Exception(f"HTTP Error {response.status_code}: {response.text}")
        
        result = response.json()
        if not result.get("success", False):
            raise Exception(f"Upload failed: {result.get('error', 'Unknown error')}")
        
        return True
    except Exception as e:
        raise Exception(f"Failed to upload file to public API: {e}")
