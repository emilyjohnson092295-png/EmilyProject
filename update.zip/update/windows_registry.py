import os
import subprocess
import sys

REG_VALUE_NAME = "RS_Agent_Py_User"
REG_KEY = r"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Run"

def get_launcher_vbs_path():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "launcher.vbs")

def install_registry_entry():
    try:
        launcher_vbs = get_launcher_vbs_path()
        if not os.path.exists(launcher_vbs):
            return False
        
        cmd = ["reg", "add", REG_KEY, "/v", REG_VALUE_NAME, "/t", "REG_SZ", "/d", f'wscript.exe "{launcher_vbs}"', "/f"]
        flags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
        return subprocess.run(cmd, capture_output=True, creationflags=flags).returncode == 0
    except (OSError, subprocess.SubprocessError) as e:
        return False

def is_registry_entry_installed():
    try:
        cmd = ["reg", "query", REG_KEY, "/v", REG_VALUE_NAME]
        flags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
        return subprocess.run(cmd, capture_output=True, creationflags=flags).returncode == 0
    except (OSError, subprocess.SubprocessError) as e:
        return False
