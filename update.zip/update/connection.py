import socket
from config import RS_SERVER_HOST, RS_SERVER_PORT

def connect_to_server():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(5)
    sock.connect((RS_SERVER_HOST, RS_SERVER_PORT))
    return sock
