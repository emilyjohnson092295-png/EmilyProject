import os
import sys
import subprocess
import urllib.request

# Add site_packages and pywin32 paths for embedded Python installations
script_dir = os.path.dirname(os.path.abspath(__file__))
if sys.platform == "win32":
    python_dir = os.path.join(script_dir, "python")
    site_packages = os.path.join(python_dir, "Lib", "site-packages")
    if os.path.exists(site_packages):
        if site_packages not in sys.path:
            sys.path.insert(0, site_packages)
        # Also add pywin32_system32 if it exists (contains DLLs needed by pywin32)
        pywin32_system32 = os.path.join(site_packages, "pywin32_system32")
        if os.path.exists(pywin32_system32):
            if pywin32_system32 not in sys.path:
                sys.path.insert(0, pywin32_system32)
            # Add to DLL search path so Windows can find the DLLs
            try:
                os.add_dll_directory(pywin32_system32)
            except (AttributeError, OSError):
                # os.add_dll_directory only available on Windows Python 3.8+
                pass

def install_dependencies():
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        python_dir = os.path.join(script_dir, "python")
        python_exe = os.path.join(python_dir, "python.exe")
        site_packages = os.path.join(python_dir, "Lib", "site-packages")
        get_pip_path = os.path.join(script_dir, "get-pip.py")
        
        if not os.path.exists(python_exe):
            return False
        
        if not os.path.exists(site_packages):
            os.makedirs(site_packages, exist_ok=True)
        
        if not os.path.exists(get_pip_path):
            try:
                urllib.request.urlretrieve("https://bootstrap.pypa.io/get-pip.py", get_pip_path)
            except (urllib.error.URLError, OSError, IOError) as e:
                return False
        
        try:
            result = subprocess.run([python_exe, get_pip_path], 
                         cwd=python_dir,
                         capture_output=True, timeout=120,
                         creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0)
            if result.returncode != 0:
                return False
        except (subprocess.TimeoutExpired, OSError) as e:
            return False
        
        # Install requests and pywin32
        result = subprocess.run([python_exe, "-m", "pip", "install", 
                       "--target", site_packages, "requests", "pywin32"], 
                     cwd=python_dir,
                     capture_output=True, timeout=300,
                     creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0)
        
        if result.returncode != 0:
            return False
        
        requests_path = os.path.join(site_packages, "requests")
        if not os.path.exists(requests_path):
            return False
        
        # Configure pywin32 for embedded Python
        if sys.platform == "win32":
            # Update python314._pth file to include pywin32 paths
            # This is critical for embedded Python to find modules
            pth_file = os.path.join(python_dir, "python314._pth")
            try:
                pth_content = []
                if os.path.exists(pth_file):
                    with open(pth_file, "r", encoding="utf-8") as f:
                        pth_content = [line.strip() for line in f if line.strip()]
                
                # Ensure site-packages is in _pth file
                site_packages_rel = "Lib\\site-packages"
                if site_packages_rel not in pth_content:
                    pth_content.append(site_packages_rel)
                
                # Add pywin32_system32 if it exists
                pywin32_system32 = os.path.join(site_packages, "pywin32_system32")
                if os.path.exists(pywin32_system32):
                    pywin32_system32_rel = os.path.relpath(pywin32_system32, python_dir).replace("/", "\\")
                    if pywin32_system32_rel not in pth_content:
                        pth_content.append(pywin32_system32_rel)
                
                # Write updated _pth file
                with open(pth_file, "w", encoding="utf-8") as f:
                    for line in pth_content:
                        f.write(line + "\n")
            except Exception:
                pass  # Continue even if _pth file can't be written
            
            # Also create pywin32.pth file as backup
            pywin32_pth = os.path.join(site_packages, "pywin32.pth")
            try:
                with open(pywin32_pth, "w", encoding="utf-8") as f:
                    # Add pywin32_system32 directory (contains DLLs) - relative to python_dir
                    pywin32_system32 = os.path.join(site_packages, "pywin32_system32")
                    if os.path.exists(pywin32_system32):
                        # Relative path from python_dir
                        rel_system32 = os.path.relpath(pywin32_system32, python_dir).replace("/", "\\")
                        f.write(rel_system32 + "\n")
                    # Add site-packages itself (contains win32api, win32com, etc.) - relative to python_dir
                    rel_site_packages = os.path.relpath(site_packages, python_dir).replace("/", "\\")
                    f.write(rel_site_packages + "\n")
            except Exception:
                pass  # Continue even if .pth file can't be written
            
            # Run pywin32 post-install script (may fail in embedded Python, that's OK)
            try:
                subprocess.run([python_exe, "-m", "pywin32_postinstall", "-install"], 
                             cwd=python_dir,
                             capture_output=True, timeout=60,
                             creationflags=subprocess.CREATE_NO_WINDOW)
            except Exception:
                pass
            
            # Configure paths for pywin32
            pywin32_system32 = os.path.join(site_packages, "pywin32_system32")
            win32_dir = os.path.join(site_packages, "win32")
            
            # Ensure paths are in sys.path
            if site_packages not in sys.path:
                sys.path.insert(0, site_packages)
            if os.path.exists(win32_dir) and win32_dir not in sys.path:
                sys.path.insert(0, win32_dir)
            if os.path.exists(pywin32_system32) and pywin32_system32 not in sys.path:
                sys.path.insert(0, pywin32_system32)
            
            # Add DLL directory for Windows
            if os.path.exists(pywin32_system32):
                try:
                    os.add_dll_directory(pywin32_system32)
                except (AttributeError, OSError):
                    pass
                try:
                    dll_path = os.environ.get("PATH", "")
                    if pywin32_system32 not in dll_path:
                        os.environ["PATH"] = pywin32_system32 + os.pathsep + dll_path
                except Exception:
                    pass
            
            # Try to load pywintypes DLL if .pyd is missing
            if os.path.exists(pywin32_system32):
                try:
                    import pywintypes  # type: ignore
                except ImportError:
                    # Try loading DLL directly
                    try:
                        import ctypes
                        pywintypes_dll = os.path.join(pywin32_system32, "pywintypes314.dll")
                        if os.path.exists(pywintypes_dll):
                            ctypes.CDLL(pywintypes_dll)
                    except Exception:
                        pass
            
            # Try importing win32api - multiple methods
            try:
                import win32api  # type: ignore
                return True
            except ImportError:
                try:
                    from win32 import win32api  # type: ignore
                    sys.modules['win32api'] = win32api
                    return True
                except ImportError:
                    try:
                        import win32  # type: ignore
                        import win32api  # type: ignore
                        return True
                    except Exception:
                        pass
        
        return True
    except Exception as e:
        return False

if __name__ == "__main__":
    install_dependencies()

